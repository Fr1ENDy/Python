import requests
from bs4 import BeautifulSoup
import io

def get_data(url):
    headers = {
        "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36"
    }
    req = requests.get(url, headers=headers)
    soup = BeautifulSoup(req.content, 'html.parser')

    for a in soup.select('a.btn.btn-default'):
        a.extract()

    with io.open('output.txt', 'w', encoding='utf-8') as f:
        div_0 = soup.find_all('div', {'class': "items-row row-0 row clearfix"})
        for div in div_0:
            text = div.get_text()
            f.write(text + "\n\n")

        div_1 = soup.find_all('div', {'class': "items-row row-1 row clearfix"})
        for div in div_1:
            text = div.get_text()
            f.write(text + "\n\n")

        div_2 = soup.find_all('div', {'class': "items-row row-2 row clearfix"})
        for div in div_2:
            text = div.get_text()
            f.write(text + "\n")

get_data("https://www.rv-it.college/index.php")
