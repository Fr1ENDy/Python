from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove

#-start menu-#
Regs = KeyboardButton("Зареєструватися")
Registration = ReplyKeyboardMarkup(resize_keyboard=True)
Registration.add(Regs)

#Кнопка назад
MainMenu = KeyboardButton("Головне меню")

#-main menu-#
#Розклад занять
Schedule = KeyboardButton("Розклад занять")
#Електроний щоденник
Diary = KeyboardButton("Електроний щоденник")
#Новини та події
News = KeyboardButton("Новини та події")
#Нагадування
Reminder = KeyboardButton("Нагадування")
main_menu = ReplyKeyboardMarkup(resize_keyboard=True)
main_menu.add(Schedule).add(Diary).add(News).add(Reminder)

#-Diary-#
Rating1 = KeyboardButton("Оцінки за 1 курс")
Rating2 = KeyboardButton("Оцінки за 2 курс")
Rating3 = KeyboardButton("Оцінки за 3 курс")
Rating4 = KeyboardButton("Оцінки за 4 курс")
daily_book = ReplyKeyboardMarkup(resize_keyboard=True)
daily_book.add(Rating1).add(Rating2).add(Rating3).add(Rating4).add(MainMenu)

#-Assessments-#
Semester1 = KeyboardButton("Оцінки за 1 семестер")
Semester2 = KeyboardButton("Оцінки за 2 семестер")
Kyrs1 = ReplyKeyboardMarkup(resize_keyboard=True)
Kyrs1.add(Semester1).add(Semester2).add(MainMenu)

Semester3 = KeyboardButton("Оцінки за 3 семестер")
Semester4 = KeyboardButton("Оцінки за 4 семестер")
Kyrs2 = ReplyKeyboardMarkup(resize_keyboard=True)
Kyrs2.add(Semester3).add(Semester4).add(MainMenu)

Semester5 = KeyboardButton("Оцінки за 5 семестер")
Semester6 = KeyboardButton("Оцінки за 6 семестер")
Kyrs3 = ReplyKeyboardMarkup(resize_keyboard=True)
Kyrs3.add(Semester5).add(Semester6).add(MainMenu)

Semester7 = KeyboardButton("Оцінки за 7 семестер")
Semester8 = KeyboardButton("Оцінки за 8 семестер")
Kyrs4 = ReplyKeyboardMarkup(resize_keyboard=True)
Kyrs4.add(Semester7).add(Semester8).add(MainMenu)
