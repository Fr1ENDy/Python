import gspread
import sqlite3
import smtplib
import time
from datetime import date
import schedule
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timedelta
from aiogram import Bot, Dispatcher, types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.utils import executor
from aiogram.contrib.fsm_storage.memory import MemoryStorage
import random
import aiocron
import logging
from aiogram.types import InputFile
import pandas as pd
import sqlite3
import uuid
# кнопки
from Keyboards.Keyboard import Registration, main_menu, daily_book, Kyrs1, Kyrs2, Kyrs3, Kyrs4

# Токен бота
TOKEN = '5974033961:AAHvtDT7kBa3soYSaIdI2BIWsnhvb595kbo'
# TOKEN = "5766712333:AAFZeQ-StYu87fwBdGbeYr307LRThEYiBaM"

# Данні з JSON файлу
credentials = {
    "type": "service_account",
    "project_id": "python-bot-380217",
    "private_key_id": "fc52acd813cd8904b0737344c1cf6b5b924c432a",
    "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCzZOtIFwQfpXa9\ng0GXJOpwWJBXa8xjo3pE7iX/PT1uMuK2K5VhT+nqSbHzj/haSZ05iMnV3sRdDulw\n53CU4HjA3BgyloYE5om56s2vrnqnpQtItxtfiCKc9EY2BMOQ11QtzUy1QMEKlji0\nYz//jIVTAylAAB8/3s37thQw66mrOcrU3+YYBZ+mUdU6YWaP9+4tisVVdQcDmEax\nXFktjPstKVk7/2l3Vv6kSAgjpx6KoFDn02JFBSbMgymMujN43EsKPwPSKZRZpIoK\nFYbs06c5laIWwrPdV3e8qX6CluhMLMUcxyfvO+T2T1+yckplT6aQ6vpk7F1bG09u\ngZ6+RDEFAgMBAAECggEADhq4fO8s/dKj5qaJOPmdYmk0KrYTrcnOn9jG2AMtRJrE\n7w8M1vJ826og+ZtaKrnFnh5pGrhBtryovJ3AYOl9KlH4/RE58Zdb62gl9SgXW1Lt\n84ZMpVLYwH+xfXxxESmSOWpTcPS/DgwIN/aNs5PixPISA4bUQ3tLCqf4J8MqOzIA\nDFqQw6DMFvJCUANDtx/lSdQZzcx/i3dqYQJFio4W3gHDeSDbmCkC49jhCi5b7z98\ng835APBCZMHCezoksbPcE/hg8Dj1GavKeJ/4O1mE1ajn7vRg+Hjd5assy+exKgBX\ntTgcyCmE3fKW/YnIataYwF+uSTECn8lDlZOl/Lp/yQKBgQDztaMbcn/NRVKmsUD5\ne+UF3edrDLfk9WF0tMGybvbI1rGA05wZfLd6GGLJvK3taTQo5d+WuTjqC4tKWM6t\nH7PMS5CJhidf3tt/Led4v8SGXJu0qOsyRFMy18EUw722WFiDBiVsAmL1w0zkmUBR\n9Uqv6bVrq5WuIgttuRVl3eF1hwKBgQC8cPO8Mh1FBuM7AldSoLI0LJec1Mv4nyQ2\nn5kqqVc6LtKomfz+6XgM5nZoFVML0lKhiM0JCqAebgXrm4+U/vB/JpiBfNXr4Mo6\nTaJN3s3ebZmQCCzEGPmeXPz1bwAG+a7gu0HQDLqcFuqFKUELDe2IktnPVbWfDYuX\nLO6UNVHIEwKBgQDFZMdZweHWB2IsdcFk0X7sw5FfWYvRPRbUiluhBNOKVKqs57i1\nxBhwIjRRpitR8jY3MglpcVix6OvHKisselMNE99cJHbb5gvu9OVZHio1kejj6TWn\nH0QsGCjhgrG0cdYvOdkxpLU2zhsHxUEdoQn/ddJmBTJVOmn7U0ALpC2rHQKBgQCF\nk6uyo/OLkq5QjgBIWhD4WwO98DoGKwkIj2mLjC6A1+AME9v69pRa0KLudO9BWf2o\n88gjuJx39ZXMxaCqBW2FNF62qz8YzWeMnKuId3+HRDmul5zkBLAtSc0mTWC/kQ4d\nz59/UwaUzsm/StcIdv8B6Nbs2dy8umVQ7FDSTlmCcQKBgDv8btUxnsCP0zxoPrJe\nrhWgQ9O7wJ4qLIlqi5i44KB3OrpKbapFQk9OTv99fvWD++aMfmy6+TPqkDy1yUoS\n5Dk3FeDOpxzrDky0ukA4MKRx4AEP/0qQ5zky4ycBkIx7TY+n24g25wnTTo0dyutJ\nAuYVUOqDSL5L8lVI0uztu1zJ\n-----END PRIVATE KEY-----\n",
    "client_email": "telegram-bot@python-bot-380217.iam.gserviceaccount.com",
    "client_id": "105877812806154767668",
    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
    "token_uri": "https://oauth2.googleapis.com/token",
    "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
    "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/telegram-bot%40python-bot-380217.iam.gserviceaccount.com"
}

# Піключаємось до бази данних
conn = sqlite3.connect('bot.db')
cursor = conn.cursor()
# перевірка підключення
if conn:
    print('База данних підключена')
else:
    print('База данних не підключена')

bot = Bot(token=TOKEN)
storage = MemoryStorage()
dp = Dispatcher(bot, storage=storage)
gc = gspread.service_account_from_dict(credentials)
token_data = ""
logging.basicConfig(level=logging.INFO)


# Підключаємся до локального файлу типа xlsx
df = pd.read_excel('C:\BD.xlsx', sheet_name="Sheet1")
# Записуємо значення з локальної таблиці в змінні
surname = df['Surname'][:].tolist()
print(surname)
name = df['Name'][:].tolist()
print(name)
patronym = df['Patronym'][:].tolist()
print(patronym)
group_id = df['Group'][:].tolist()
# Присвоєю кожній групі код
for i in range(len(group_id)):
    if group_id[i] == "ІПЗ-1":
        group_id[i] = 12101
    elif group_id[i] == "ІПЗ-3":
        group_id[i] = 12103
    elif group_id[i] == "ІПЗ-5":
        group_id[i] = 12105
    else:
        group_id[i] = 00000
print(group_id)
email = df['Email'][:].tolist()
print(email)
# Генерация уникального идентификатора для каждого студента
ids = [str(uuid.uuid4()) for _ in range(len(name))]
print(ids)

# Структура бази данних
# Створення таблиці Groups
cursor.execute("""
CREATE TABLE IF NOT EXISTS Groups (
    id INTEGER PRIMARY KEY,
    name TEXT NOT NULL
);
""")

#Створення таблиці Student
cursor.execute("""
CREATE TABLE IF NOT EXISTS Student (
    id TEXT PRIMARY KEY,
    chat_id INTEGER NOT NULL,
    surname TEXT NOT NULL,
    name TEXT NOT NULL,
    patronym TEXT NOT NULL,
    group_id INTEGER NOT NULL,
    email TEXT NOT NULL,
    logged BOOLEAN DEFAULT 0,
    FOREIGN KEY (group_id) REFERENCES Groups(id)
);
""")

# Запис даних у таблицю Student бази даних SQLite
for i in range(len(ids)):
    cursor.execute("INSERT OR IGNORE INTO Student (id, surname, name, patronym, group_id, email ) VALUES (?, ?, ?, ?, ?, ?)",
                   (ids[i], surname[i], name[i], patronym[i], group_id[i], email[i]))

# Читання даних з таблиці Student бази даних SQLite та виведення на екран
cursor.execute("SELECT * FROM Student")
rows = cursor.fetchall()
for row in rows:
    print(row)

# Створення таблиці Login Token
cursor.execute("""
CREATE TABLE IF NOT EXISTS Login_Token (
    id INTEGER PRIMARY KEY,
    value TEXT NOT NULL,
    student_id INTEGER NOT NULL,
    sent BOOLEAN DEFAULT 0,
    used BOOLEAN DEFAULT 0,
    due_date TIMESTAMP NOT NULL,
    FOREIGN KEY (student_id) REFERENCES Student(id)
);
""")
# Створення таблиці Message
cursor.execute("""
CREATE TABLE IF NOT EXISTS Message (
    id INTEGER PRIMARY KEY,
    sender TEXT NOT NULL,
    text TEXT NOT NULL,
    groups TEXT NOT NULL,
    send_time TIMESTAMP NOT NULL,
    row_number INTEGER NOT NULL,
    status TEXT
);
""")

# Отримання даних із таблиці (Google Sheets) Message
# Запис данних з Google Sheets в бд
def write_to_database(sdata):
    id = [row[0] for row in sdata[1:]]
    Sender_Message = [row[1] for row in sdata[1:]]
    Text_Message = [row[2] for row in sdata[1:]]
    Groups_Message = [row[3] for row in sdata[1:]]
    DateToSend_Message = [row[4] for row in sdata[1:]]
    RowSend_Message = [row[5] for row in sdata[1:]]
    Status_Message = [row[6] for row in sdata[1:]]
    for i in range(len(id)):
        cursor.execute("INSERT or IGNORE into Message (id,sender,text,groups,send_time,row_number,status) VALUES (?, ?, ?, ?, ?, ?, ?)",
                       (id[i], Sender_Message[i], Text_Message[i], Groups_Message[i], DateToSend_Message[i], RowSend_Message[i], Status_Message[i]))
    conn.commit()


@aiocron.crontab('*/1 * * * *')
async def Not():
    write_to_database(sdata=Message.get_all_values())
    now = datetime.now()
    cursor.execute("SELECT * FROM Message")
    message_table = cursor.fetchall()
    cursor.execute("SELECT * FROM Student")
    student_table = cursor.fetchall()
    for message in message_table:
        if (message[6] != 'send'):
            for student in student_table:
                if (student[3] in message[3]):
                    if (student[5] is None):
                        continue
                    else:
                        if (message[4] == now.strftime("%H:%M %d/%m/%Y")):
                            await bot.send_message(student[5], message[2])
                            cursor.execute(
                                f'UPDATE Message SET status= ? WHERE id= ?', ('send', message[0]))
                            conn.commit()

# Створюємо класи


class Student:
    def __init__(self, id, email, logged, name, group_id, chat_id):
        self.id = id
        self.email = email
        self.logged = logged
        self.name = name
        self.group_id = group_id
        self.chat_id = chat_id


def get_student(student_id: int) -> Student:
    cursor.execute(f"UPDATE Student SET logged=1 WHERE id={student_id}")
    conn.commit()
    cursor.execute(f"SELECT * FROM Student WHERE id={student_id}")
    student_data = cursor.fetchone()
    student = Student(*student_data)
    return student


async def process_email_handler(message: types.Message, state: FSMContext) -> None:
    # Перевіяємо, чи існує користувач із цією електронною адресою в базі данних
    email = message.text.lower().strip()
    cursor.execute(f"SELECT * FROM student WHERE LOWER(email)='{email}'")
    student_data = cursor.fetchone()
    chat_id = message.chat.id
    # Записуємо в таблицю chat id користувача
    cursor.execute(
        "UPDATE Student SET chat_id = ? WHERE email = ?", (chat_id, email))
    conn.commit()

    if not student_data:
        await message.answer("Користувача з такою електронною поштою не знайдено. Спробуйте ще раз.")
        return

    # Генерація новго токену, та надсилання його на почту
    student_id = student_data[0]
    token = generate_token(student_id)
    await send_token(token, email)

    # Зберігайте інформацію про користувача в FSM
    await state.update_data(student_id=student_id, token=token)
    await AuthStates.waiting_for_token.set()

# Генерація токену для бази данних


def generate_token(student_id: int) -> str:
    if token_data:
        token = token_data[0]
    else:
        token = random.randint(1000, 9999)
        cursor.execute(
            f"INSERT INTO login_token (value, student_id, sent, used, due_date) VALUES ('{token}', {student_id}, 0, 0, '{(datetime.now() + timedelta(hours=1)).isoformat()}')")
        conn.commit()

    return token


# Надсилання токену на почту
async def send_token(token: str, email: str) -> None:
    username = "d.maksim4ik69@gmail.com"
    password = "lpvtgmormpqalhgj"
    mail_from = "d.maksim4ik69@gmail.com"
    mail_to = email
    mail_subject = "Verefication"
    mail_body = f"Ваш код для авторизації в телеграм боті : {token} "
    mimemsg = MIMEMultipart()
    mimemsg['From'] = mail_from
    mimemsg['To'] = mail_to
    mimemsg['Subject'] = mail_subject
    mimemsg.attach(MIMEText(mail_body))

    try:
        smtpObj = smtplib.SMTP('smtp.gmail.com', 587)
        smtpObj.starttls()
        smtpObj.login(username, password)
        smtpObj.sendmail(mail_from, mail_to, mimemsg.as_string())
        smtpObj.quit()
        print(f"Токен відправлено на адресу {email} Токен: {token}")
    except smtplib.SMTPException as e:
        print(f"Error: {e}")
        # Міняємo значення в колонці sent на 1
        cursor.execute("UPDATE Login_Token SET sent=1 WHERE value=?", (token,))
        conn.commit()


class AuthStates(StatesGroup):
    waiting_for_email = State()
    waiting_for_token = State()


# @aiocron.crontab('0 8,12,16 * * *')
# async def send_all_values():
#     for user in Users.get_all_values():
#         await bot.send_message(user[0], Message.get_all_values())

# Повідомлення при команді /start


@dp.message_handler(commands=['start'])
async def process_start_command(message: types.Message):
    if message.text == "/start":
        # Перевіряємо чи користувач зареєстрований
        telegram_id = message.from_user.id
        cursor.execute(
            "SELECT logged FROM student WHERE chat_id = ?", (telegram_id,))
        result = cursor.fetchone()
        if result is not None and result[0]:
            # Користувач зареєстрований, виводимо головне меню
            await message.answer("Головне меню:", reply_markup=main_menu)
        else:
            # Користувач не зареєстрований, просимо зареєструватися
            await message.answer("Ви ще не зареєстровані. Будь ласка, нажміть кнопку зареєструватись", reply_markup=Registration)


@ dp.message_handler()
async def main(message: types.Message):
    if message.text == "Зареєструватися":
        await message.answer("Вітаємо! Введіть свою електронну пошту для отримання коду авторизації.")
        await AuthStates.waiting_for_email.set()

        @ dp.message_handler(state=AuthStates.waiting_for_email)
        async def process_email(message: types.Message, state: FSMContext):
            await process_email_handler(message, state)
            await message.answer("Токен надіслано на почту, введіть його")

        @ dp.message_handler(state=AuthStates.waiting_for_token)
        async def process_token(message: types.Message, state: FSMContext):
            data = await state.get_data()
            student_id = data.get("student_id")
            token = data.get("token")
            cursor.execute(
                f"SELECT * FROM login_token WHERE value='{message.text}' AND used=0")
            token_data = cursor.fetchone()
            if token_data is None:
                await message.answer("Код авторизації недійсний. Спробуйте ще раз.")
            else:
                cursor.execute(
                    f"UPDATE login_token SET used=1 WHERE value='{message.text}'")
                conn.commit()
                cursor.execute(f"SELECT * FROM student WHERE id={student_id}")
                student_data = cursor.fetchone()
                if student_data is None:
                    await message.answer(
                        "Користувача з таким ID не знайдено в базі даних. Будь ласка, зареєструйтесь спочатку.")
                else:
                    # Оновлення значення "logged" на 1 для студента
                    cursor.execute(
                        f"UPDATE Student SET logged=1 WHERE id={student_id}")
                    conn.commit()

                    student = Student(*student_data)
                    await message.answer(f"Вітаємо, {student.email}! Ви успішно авторизувались.")
                    await state.finish()
                    await message.answer("Ось меню, яке ви можете використовувати: ", reply_markup=main_menu)

    elif message.text == "Розклад занять":
        telegram_id = message.from_user.id
        cursor.execute("SELECT group_id FROM student WHERE chat_id=?", (telegram_id,))
        row = cursor.fetchone()
        if row is not None:
            group_id = row[0]
            if group_id == 12101:
                # Відправляємо фото для групи іпз-1
                with open('photo12101.jpg', 'rb') as photo:
                    # Відправляємо фото
                    await bot.send_photo(chat_id=message.chat.id, photo=InputFile(photo))
            elif group_id == 12103:
                # Відправляємо фото для групи іпз-3
                with open('photo12103.jpg', 'rb') as photo:
                    # Відправляємо фото
                    with open('photo12103.jpg', 'rb') as photo:
                        # Відправляємо фото
                        await bot.send_photo(chat_id=message.chat.id, photo=InputFile(photo))
            elif group_id == "12105":
                # Відправляємо фото для групи іпз-5
                with open('photo12105.jpg', 'rb') as photo:
                    # Відправляємо фото
                    await bot.send_photo(chat_id=message.chat.id, photo=InputFile(photo))
            else:
                # Якщо код не відповідає жодному з вказаних значень
                print("Невідомий код групи")
        else:
            # Якщо chat_id не знайдено в базі даних, або користувач не зареєструвався
            print("Користувач не знайдений в базі даних")

        conn.commit()

    elif message.text == "Нагадування":
        await bot.send_message(message.from_user.id, Message.get_all_values())

    elif message.text == "Електроний щоденник":
        await message.answer("Електроний щоденник", reply_markup=daily_book)

    elif message.text == "Оцінки за 1 курс":
        await message.answer("Оцінки за 1 курс", reply_markup=Kyrs1)

    elif message.text == "Оцінки за 2 курс":
        await message.answer("Оцінки за 2 курс", reply_markup=Kyrs2)

    elif message.text == "Оцінки за 3 курс":
        await message.answer("Оцінки за 3 курс", reply_markup=Kyrs3)

    elif message.text == "Оцінки за 4 курс":
        await message.answer("Оцінки за 4 курс", reply_markup=Kyrs4)

    elif message.text == "Головне меню":
        await message.answer('Головне меню', reply_markup=main_menu)


if __name__ == '__main__':
    executor.start_polling(dp)
    # asyncio.get_event_loop().run_forever()
